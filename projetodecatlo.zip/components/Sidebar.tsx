"use client";

import {
  ClipboardList,
  History,
  LayoutDashboard,
  List,
  LogOut,
  Monitor,
  PlusCircle,
  Users,
  X,
} from "lucide-react";
import { signOut } from "next-auth/react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useUser } from "@/contexts/UserContext";
interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}
const menuSections = [
  {
    title: "Menu principal",
    items: [
      {
        href: "/dashboard",
        label: "Visão geral",
        icon: LayoutDashboard,
        permission: "dashboard.acessar",
      },
    ],
  },

  {
    title: "Partidas",
    items: [
      {
        href: "/dashboard/partidas/nova",
        label: "Nova partida",
        icon: PlusCircle,
        permission: "jogo.configurar",
      },
      {
        href: "/dashboard/partidas",
        label: "Partidas",
        icon: List,
        permission: "jogo.configurar",
      },
    ],
  },

  {
    title: "Banco de perguntas",
    items: [
      {
        href: "/dashboard/gerenciamento-perguntas",
        label: "Perguntas",
        icon: ClipboardList,
        permission: "perguntas.gerenciar",
      },
    ],
  },

  {
    title: "Administração",
    items: [
      {
        href: "/dashboard/usuarios",
        label: "Usuários",
        icon: Users,
        permission: "usuarios.gerenciar",
      },
      {
        href: "/dashboard/auditoria",
        label: "Auditoria",
        icon: History,
        permission: "auditoria.visualizar",
      },
    ],
  },
] satisfies {
  title: string;
  items: {
    href: string;
    label: string;
    icon: typeof LayoutDashboard;
    permission: string;
  }[];
}[];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const pathname = usePathname();
  const { user } = useUser();

  if (!user) {
    return null;
  }

  const permissions = user.permissions ?? [];
  return (
    <>
      {isOpen && (
        <button
          type="button"
          aria-label="Fechar menu"
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/40 lg:hidden"
        />
      )}

      <aside
        className={`
          fixed inset-y-0 left-0 z-50 flex w-72 flex-col
          bg-slate-950 text-white
          transition-transform duration-300
          lg:static lg:z-auto lg:translate-x-0
          ${isOpen ? "translate-x-0" : "-translate-x-full"}
        `}
      >
        <div className="flex h-20 items-center justify-between border-b border-slate-800 px-6">
          <Link href="/" onClick={onClose}>
            <p className="text-xl font-bold tracking-widest">DECATLO</p>

            <p className="mt-1 text-xs text-slate-400">Sistema de Arguição</p>
          </Link>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white lg:hidden"
            aria-label="Fechar menu"
          >
            <X size={22} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-4 py-6">
          {menuSections.map((section) => {
            const visibleItems = section.items.filter((item) => {
              if (item.href === "/dashboard/partidas/nova" && user?.role === "Apresentador") {
                return false;
              }
              return permissions.includes(item.permission);
            });

            if (visibleItems.length === 0) {
              return null;
            }

            return (
              <div key={section.title} className="mb-7">
                <p className="mb-3 px-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
                  {section.title}
                </p>

                <div className="space-y-1">
                  {visibleItems.map((item) => {
                    const Icon = item.icon;
                    let isActive = false;
                    if (item.href === "/dashboard") {
                      isActive = pathname === "/dashboard";
                    } else if (item.href === "/dashboard/partidas") {
                      isActive = pathname === "/dashboard/partidas" || (pathname.startsWith("/dashboard/partidas/") && !pathname.startsWith("/dashboard/partidas/nova"));
                    } else {
                      isActive = pathname.startsWith(item.href);
                    }

                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        onClick={onClose}
                        className={`flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium transition ${
                          isActive
                            ? "bg-sky-600 text-white"
                            : "text-slate-300 hover:bg-slate-800 hover:text-white"
                        }`}
                      >
                        <Icon size={19} strokeWidth={1.8} />

                        <span>{item.label}</span>
                      </Link>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {permissions.includes("telao.abrir") && (
            <div className="border-t border-slate-800 pt-6">
              <p className="mb-3 px-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
                Apresentação
              </p>

              <Link
                href="/telao"
                target="_blank"
                className="flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium text-slate-300 transition hover:bg-slate-800 hover:text-white"
              >
                <Monitor size={19} strokeWidth={1.8} />

                <span>Ver telão</span>
              </Link>
            </div>
          )}
        </nav>

        <div className="border-t border-slate-800 p-4">
          <button
            type="button"
            onClick={() => {
              onClose();
              void signOut({ callbackUrl: "/" });
            }}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-sm text-slate-400 transition hover:bg-slate-800 hover:text-white"
          >
            <LogOut size={18} />

            <span>Sair</span>
          </button>
        </div>
      </aside>
    </>
  );
}
